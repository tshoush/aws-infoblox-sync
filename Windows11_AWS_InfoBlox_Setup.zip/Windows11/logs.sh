#!/bin/bash
echo "Showing container logs..."
echo "Press Ctrl+C to exit"
echo "================================================"
docker logs -f infoblox-tag-mapper