#!/bin/bash
echo "Stopping AWS-InfoBlox container..."
docker compose down
echo "Container stopped."